package br.com.gestaotec.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.gestaotec.models.Marca;
import br.com.gestaotec.repositories.MarcaRepository;

@RestController
@RequestMapping(path = "/marcas")
public class MarcaResource {
    
    private MarcaRepository marcaRepository;

    public MarcaResource(MarcaRepository marcaRepository){
        super();
        this.marcaRepository = marcaRepository;
    }

    @GetMapping
    public ResponseEntity<List<Marca>> getAll(){
        List<Marca> marcas = new ArrayList<>();
        marcas = marcaRepository.findAll();
        return new ResponseEntity<>(marcas, HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<Optional<Marca>> getById(@PathVariable Long id){
        Optional<Marca> marca;
        try{
            marca = marcaRepository.findById(id);
            return new ResponseEntity<Optional<Marca>>(marca, HttpStatus.OK);
        }catch(NoSuchElementException ex){
            return new ResponseEntity<Optional<Marca>>(HttpStatus.NOT_FOUND);
        }
        
    }

    @PostMapping
    public ResponseEntity<Marca> save(@RequestBody Marca marca){
        marcaRepository.save(marca);
        return new ResponseEntity<>(marca, HttpStatus.CREATED);
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<Optional<Marca>> deleteById(@PathVariable(value = "id") Long id){
        try{
            marcaRepository.deleteById(id);
            return new ResponseEntity<Optional<Marca>>(HttpStatus.OK);
        }catch(NoSuchElementException ex){
            return new ResponseEntity<Optional<Marca>>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping(path = "/{id}")
    public ResponseEntity<Marca> update(@PathVariable(value = "id") Long id, @RequestBody Marca novaMarca){
        return marcaRepository.findById(id)
        .map(marca -> {
            marca.setDescricao(novaMarca.getDescricao());
            Marca marcaAtualizada = marcaRepository.save(marca);
            return ResponseEntity.ok().body(marcaAtualizada);
        }).orElse(ResponseEntity.notFound().build());
    }
}
