package br.com.gestaotec.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import br.com.gestaotec.models.Produto;
import br.com.gestaotec.repositories.ProdutoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/produtos")
public class ProductResource {
    
    private ProdutoRepository produtoRepository;

    public ProductResource(ProdutoRepository produtoRepository){
        super();
        this.produtoRepository = produtoRepository;
    }

    @GetMapping
    public ResponseEntity<List<Produto>> getAll(){
        List<Produto> produtos = new ArrayList<>();
        produtos = produtoRepository.findAll();
        return new ResponseEntity<>(produtos, HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<Optional<Produto>> getById(@PathVariable Long id){
        Optional<Produto> produto;
        try{
            produto = produtoRepository.findById(id);
            return new ResponseEntity<Optional<Produto>>(produto, HttpStatus.OK);
        }catch(NoSuchElementException ex){
            return new ResponseEntity<Optional<Produto>>(HttpStatus.NOT_FOUND);
        }
        
    }

    @PostMapping
    public ResponseEntity<Produto> save(@RequestBody Produto produto){
        produtoRepository.save(produto);
        return new ResponseEntity<>(produto, HttpStatus.CREATED);
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<Optional<Produto>> deleteById(@PathVariable Long id){
        try{
            produtoRepository.deleteById(id);
            return new ResponseEntity<Optional<Produto>>(HttpStatus.OK);
        }catch(NoSuchElementException ex){
            return new ResponseEntity<Optional<Produto>>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping(path = "/{id}")
    public ResponseEntity<Produto> update(@PathVariable Long id, @RequestBody Produto novoProduto){
        return produtoRepository.findById(id)
        .map(prod -> {
            prod.setDescricao(novoProduto.getDescricao());
            prod.setDataValidade(novoProduto.getDataValidade());
            Produto produtoAtualizado = produtoRepository.save(prod);
            return ResponseEntity.ok().body(produtoAtualizado);
        }).orElse(ResponseEntity.notFound().build());
    }

}
