package br.com.gestaotec.models;

import javax.persistence.*;
import java.util.List;

@Entity
public class Marca {

    @GeneratedValue
    @Id
    private Long id;

    @Column(name = "descricaoMarca")
    private String descricao;

    @OneToMany
    private List<Produto> produtos;

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return this.descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

}
